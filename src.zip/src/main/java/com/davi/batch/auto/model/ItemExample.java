package com.davi.batch.auto.model;

import com.davi.batch.entity.oracle.EntityDb01Example;

public class ItemExample {

	private EntityDb01Example entityDb01Example;
	
	public ItemExample() {
	}

	public EntityDb01Example getEntityExample() {
		return entityDb01Example;
	}

	public void setEntityDb01Example(EntityDb01Example entityDb01Example) {
		this.entityDb01Example = entityDb01Example;
	}
	
}
